//
//  LCLrcLine.h
//  test1
//
//  Created by 芦超 on 16/1/12.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LCLrcLine : NSObject
/**
    时间点
 */
@property (nonatomic, copy) NSString *time;
/**
    词
 */
@property (nonatomic, copy) NSString *word;
/**
    返回所有的歌词model
 
 */
+ (NSMutableArray *)lrcLinesWithFileName:(NSString *)fileName;
@end
