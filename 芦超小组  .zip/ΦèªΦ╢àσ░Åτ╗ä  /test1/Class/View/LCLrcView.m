//
//  LCLrcView.m
//  test1
//
//  Created by 芦超 on 16/1/12.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "LCLrcView.h"

@interface LCLrcView()

@property (nonatomic, weak) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *lrcLines;

@end

@implementation LCLrcView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)setFileName:(NSString *)fileName
{
    if ([_fileName isEqualToString:fileName]) {
        return;
    }
    _fileName = [fileName copy];
    [_lrcLines removeAllObjects];
    _lrcLines = nil;
    [self.tableView reloadData];
}
@end
