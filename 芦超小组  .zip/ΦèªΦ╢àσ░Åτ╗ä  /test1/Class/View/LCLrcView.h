//
//  LCLrcView.h
//  test1
//
//  Created by 芦超 on 16/1/12.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LCLrcView : UIImageView
@property (nonatomic, copy) NSString *fileName;
@end
