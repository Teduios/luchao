//
//  LCMusicTool.m
//  20160107
//
//  Created by tarena on 16/1/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "LCMusicTool.h"
#import "LCMusic.h"
#import "MJExtension.h"

static NSArray *_musics;
static LCMusic *_playingMusic;

@implementation LCMusicTool

+ (NSArray *)musics {
    if (_musics == nil) {
        NSString *plistPath = [[NSBundle mainBundle]pathForResource:@"Musics.plist" ofType:nil];
        _musics = [NSArray arrayWithContentsOfFile:plistPath];
        NSMutableArray *mutableArray = [NSMutableArray array];
        for (NSDictionary *dic in _musics) {
            LCMusic *musicLC = [[LCMusic alloc] init];
            [musicLC setValuesForKeysWithDictionary:dic];
            [mutableArray addObject:musicLC];
        }
        _musics = [mutableArray copy];
}
    return _musics;
}
+(LCMusic *)playingMusic {
    return _playingMusic;
}

+ (void)setPlayingMusic:(LCMusic *)playingMusic
{
    if (playingMusic == nil || ![_musics containsObject:playingMusic] || playingMusic == _playingMusic) {
        return;
    }
    _playingMusic = playingMusic;
}

+(LCMusic *)previousMusic {
    int previousIdex = 0;
    if (_playingMusic) {
        int playingIndex = (int)[[self musics]indexOfObject:_playingMusic];
        previousIdex = playingIndex -1;
        if (previousIdex < 0) {
        previousIdex = (int)[self musics].count - 1;
        }
    }
    return [self musics][previousIdex];
}

+(LCMusic *)nextMusic {
    int nextIndex = 0;
    if (_playingMusic) {
        int playingIndex = (int)[[self musics] indexOfObject:_playingMusic];
        nextIndex = playingIndex +1;
        if (nextIndex >=[self musics].count) {
            nextIndex = 0;
        }
    }
    return [self musics][nextIndex];
}
@end
