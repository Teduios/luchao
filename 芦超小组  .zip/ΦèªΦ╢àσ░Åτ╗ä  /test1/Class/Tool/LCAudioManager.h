//
//  LCAudioManager.h
//  20160107
//
//  Created by tarena on 16/1/9.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface LCAudioManager : NSObject
+ (instancetype)defaultManager;

//播放音乐
- (AVAudioPlayer *)playingMusic:(NSString *)fileName;
- (void)pasueMusic:(NSString *)fileName;
- (void)stopMusic:(NSString *)fileName;

//播放音乐
- (void)playSound:(NSString *)fileName;
- (void)disposeSound:(NSString *)fileName;

@end
