//
//  LCMusicTool.h
//  20160107
//
//  Created by tarena on 16/1/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LCMusic;
@interface LCMusicTool : NSObject
/**
 
 正在播放的歌曲
 
 */
+(LCMusic *) playingMusic;
/**
 
 重新设置歌曲
 
 */
+(void) setPlayingMusic:(LCMusic *)playingMusic;

/**
 
 @return 所有歌曲
 */
+ (NSArray *)musics;

/**
 *  下一首歌曲
 */
+ (LCMusic *)nextMusic;

/**
 *  上一首歌曲
 */
+(LCMusic *)previousMusic;

@end
