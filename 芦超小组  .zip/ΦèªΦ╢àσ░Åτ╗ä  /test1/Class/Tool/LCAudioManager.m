//
//  LCAudioManager.m
//  20160107
//
//  Created by tarena on 16/1/9.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "LCAudioManager.h"

@interface LCAudioManager ()
@property (nonatomic, strong) NSMutableDictionary *musicPlayers;
@property (nonatomic, strong) NSMutableDictionary *soundIDs;
@end

static LCAudioManager *_instance = nil;

@implementation LCAudioManager

+ (void)initialize {
    
    //音频会话
    AVAudioSession *session = [AVAudioSession sharedInstance];
    
    //如果在真机上想要后台播放歌曲，除了在appDelegate以及plist里面做相应操作之外，还得将播放模式设置为:AVAudioSessionCategoryPlayback。
    //设置会话类型(播放类型,播放模式.会自动停止其它音乐的播放)
    [session setCategory:AVAudioSessionCategoryPlayback error:nil];
    
    //激活会话
    [session setActive:YES error:nil];
}

+ (instancetype)defaultManager
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[self alloc] init];
    });
    return _instance;
}

- (instancetype)init
{
    __block LCAudioManager *temp = self;

    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if ((temp = [super init]) !=nil) {
            _musicPlayers = [NSMutableDictionary dictionary];
            _soundIDs = [NSMutableDictionary dictionary];
        }
    });
    self = temp;
    return self;
}

+(instancetype)allocWithZone:(struct _NSZone *)zone
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [super allocWithZone:zone];
    });
    return _instance;
}

//播放音乐
- (AVAudioPlayer *)playingMusic:(NSString *)fileName {
    if (fileName == nil || fileName.length == 0) return nil;
    
    //先查询对象是否缓存
    AVAudioPlayer *player = self.musicPlayers[fileName];
    
    if (!player) {
        NSURL *url = [[NSBundle mainBundle]URLForResource:fileName withExtension:nil];
        
        if (!url) return nil;
        
        player = [[AVAudioPlayer alloc]initWithContentsOfURL:url error:nil];
        if (![player prepareToPlay]) {
            return nil;
        }
        
        //对象是最新创建的, 那么对它进行一次缓存
        self.musicPlayers[fileName] = player;
    }
    
    //如果没有症状播放,那么开始播放,如果正在播放那么不做改变
    if (![player isPlaying]) {
        [player play];
    }
    return player;
}

-(void)pasueMusic:(NSString *)fileName {
    if (fileName == nil || fileName.length == 0) return;
    
    AVAudioPlayer *player = self.musicPlayers[fileName];
    
    if ([player isPlaying]) {
        [player pause];
    }
}

-(void)stopMusic:(NSString *)fileName {
    if (fileName == nil || fileName.length == 0) {
        return;
    }
    AVAudioPlayer *player = self.musicPlayers[fileName];
    [player stop];
    
    [self.musicPlayers removeObjectForKey:fileName];
}

//播放音效
- (void)playSound:(NSString *)fileName {
    if (!fileName) {
        return;
    }
    //取出对应的音效ID
    SystemSoundID soundID = (int)[self.soundIDs[fileName]unsignedLongLongValue];
    
    if (!soundID) {
        NSURL *url = [[NSBundle mainBundle]URLForResource:fileName withExtension:nil];
        if (!url) {
            return;
        }
        AudioServicesCreateSystemSoundID((__bridge CFURLRef)(url), &soundID);
        
        self.soundIDs[fileName] = @(soundID);
    }
    
    //播放
    AudioServicesPlaySystemSound(soundID);
}

//摧毁音效
- (void)disposeSound:(NSString *)fileName {
    if (!fileName) {
        return;
    }
    SystemSoundID soundID = (int)[self.soundIDs[fileName]unsignedLongLongValue];
    
    if (soundID) {
        AudioServicesDisposeSystemSoundID(soundID);
        [self.soundIDs removeObjectForKey:fileName];//音效被摧毁.那么对应的对象应该从缓存移除
    }
}


@end
