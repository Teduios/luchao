//
//  LCMusicTableViewController.m
//  20160107
//
//  Created by tarena on 16/1/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "LCMusicTableViewController.h"
#import "LCPlayingViewController.h"
#import "LCMusicTool.h"
#import "LCMusic.h"
#import "LCMusicCell.h"

@interface LCMusicTableViewController ()
@property (nonatomic, strong)LCPlayingViewController *playingVc;

@property (nonatomic, assign) int currentIndex;
@end

@implementation LCMusicTableViewController
- (LCPlayingViewController *)playingVc {
    if (_playingVc ==nil) {
        _playingVc = [[LCPlayingViewController alloc]init];
    }
    return _playingVc;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"self.qwe.asd.ads%%, @@");
    [self setupNavigation];
}

- (void)setupNavigation {
    self.navigationItem.title = @"音乐播放器";
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [LCMusicTool musics].count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    LCMusicCell *cell = [LCMusicCell musicCellWithTableView:tableView];
    cell.music = [LCMusicTool musics][indexPath.row];
    
    return cell;
}

#pragma mark --TableViewDelegate
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [LCMusicTool setPlayingMusic:[LCMusicTool musics][indexPath.row]];
    
    LCMusic *preMusic = [LCMusicTool musics][self.currentIndex];
    preMusic.playing = NO;
    LCMusic *music = [LCMusicTool musics][indexPath.row];
    music.playing = YES;
    
    NSArray *indexPaths = @[[NSIndexPath indexPathForItem:self.currentIndex inSection:0],indexPath];
    
    [self.tableView reloadRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationNone];
    
    self.currentIndex = (int)indexPath.row;
    
    [self.playingVc show];
    
}






@end
