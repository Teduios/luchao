//
//  LCPlayingViewController.m
//  20160107
//
//  Created by tarena on 16/1/7.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "LCPlayingViewController.h"
#import "LCMusic.h"
#import "LCMusicTool.h"
#import "LCAudioManager.h"
#import "UIView+Extension.h"
#import "LCLrcView.h"
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>
#import "UIView+AutoLayout.h"



@interface LCPlayingViewController () <AVAudioPlayerDelegate>

@property (nonatomic, strong) LCMusic *playingMusic;
@property (nonatomic, strong) AVAudioPlayer *player;

@property (nonatomic,weak) LCLrcView *lrcView;
/**
   歌曲/歌手 图片
 
 */
@property (strong, nonatomic) IBOutlet UIImageView *iconView;

/**
   歌手名字
 */
@property (strong, nonatomic) IBOutlet UILabel *singerLabel;
/**
   歌曲名字
 */
@property (strong, nonatomic) IBOutlet UILabel *songLabel;
/** 
    播放\暂停按钮
 */
@property (weak, nonatomic) IBOutlet UIButton *playOrPauseButton;
/**
    歌曲滑块
 */
@property (weak, nonatomic) IBOutlet UIButton *slider;
/** 
    歌曲进度颜色背景
 */
@property (weak, nonatomic) IBOutlet UIView *progressView;
/** 
   整首歌的时长
 */
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

/**
   滑块上面小时当前时间的label
 */
@property (weak, nonatomic) IBOutlet UIButton *showProgressLabel;


@property (weak, nonatomic) IBOutlet UIView *bottomView;
@property (weak, nonatomic) IBOutlet UIView *topView;

@property (weak, nonatomic) IBOutlet UIButton *exitBtn;
@property (weak, nonatomic) IBOutlet UIButton *lyrucOrPhotoBtn;


/** 
   显示图片还是歌词
 */
- (IBAction)lyricOrPhoto:(id)sender;
/**
   暂停或者播放
 */
- (IBAction)playOrPause:(id)sender;

/** 
   退下窗口
 */
- (IBAction)exit:(UIButton *)sender;

/** */

/** */

- (IBAction)previous:(id)sender;
- (IBAction)next:(id)sender;

@end

@implementation LCPlayingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}


-(void)show {
    {
        //    NSLog(@"%@",NSStringFromCGRect(self.view.frame));
        UIWindow *windows = [UIApplication sharedApplication].keyWindow;
        self.view.bounds = windows.bounds;
        [windows addSubview:self.view];
        self.view.y = self.view.height;
        self.view.hidden = NO;
        if (self.playingMusic != [LCMusicTool playingMusic]) {
            [self resetPlayingMusic];
        }
        
        windows.userInteractionEnabled = NO;         //以免在动画过程中用户多次点击，或者造成其他事件的发生
        [UIView animateWithDuration:0.25 animations:^{
            self.view.y = 0;
        }completion:^(BOOL finished) {
            windows.userInteractionEnabled = YES;
            [self startPlayingMusic];
        }];
    }
    
}

#pragma mark ------音乐控制 (注意:歌词和锁屏的设置在这下面)
//重置播放的歌曲
- (void)resetPlayingMusic {
    //重置界面数据
    self.iconView.image = [UIImage imageNamed:@"play_cover_pic_bg"];
    self.singerLabel.text = nil;
    self.songLabel.text = nil;
//    self.timeLabel.text = [self stringWithTime:0];
    self.slider.x = 0;
    self.progressView.width = self.slider.center.x;
//    [self.slider setTitle:<#(nullable NSString *)#> forState:<#(UIControlState)#>];
    
    //停止播放音乐
    [[LCAudioManager defaultManager] stopMusic:self.playingMusic.filename];
    self.player = nil;
    
    //清空歌词
    /**
       暂时没有实现歌词功能 20160111
     */
    
    
}

//开始播放音乐
- (void)startPlayingMusic {
    if (self.playingMusic == [LCMusicTool playingMusic]) {
        
        
        return;
    }
    
    //设置所需要的数据
    self.playingMusic = [LCMusicTool playingMusic];
    self.iconView.image = [UIImage imageNamed:self.playingMusic.icon];
    self.songLabel.text = self.playingMusic.name;
    self.singerLabel.text = self.playingMusic.singer;
    
    //开始播放音乐
    self.player = [[LCAudioManager defaultManager]playingMusic:self.playingMusic.filename];
    self.player.delegate = self;
    
//    self.timeLabel.text = [self stringWithTime:self.player.duration];
    
    
    
    //切换歌词
    self.lrcView.fileName = self.playingMusic.lrcname;
    //切换锁屏
    
    
}

#pragma mark -----控件方法

/**
    显示歌词或者图片
 */
- (IBAction)lyricOrPhoto:(id)sender {
}

/**
    暂停/播放按钮
 */
- (IBAction)playOrPause:(id)sender {
//    if (self.playOrPauseButton.isSelected == NO) {
//        self.playOrPauseButton.selected = YES;
//        [[LCAudioManager defaultManager]playingMusic:self.playingMusic.filename];
////        [];
////        [];
//    }else {
//        self.playOrPauseButton.selected = NO;
//        [[LCAudioManager defaultManager]pasueMusic:self.playingMusic.filename];
////        [];
////        [];
//    }
    
    self.playOrPauseButton.selected = !self.playOrPauseButton.selected;
    if (self.playOrPauseButton.selected) {
        [[LCAudioManager defaultManager] pasueMusic:self.playingMusic.filename];
        [self.playOrPauseButton setImage:[UIImage imageNamed:@"play"] forState:UIControlStateNormal];
    }else{
        [[LCAudioManager defaultManager] playingMusic:self.playingMusic.filename];
        [self.playOrPauseButton setImage:[UIImage imageNamed:@"pause"] forState:UIControlStateNormal];
    }
}

/** 将控制器退下 */
- (IBAction)exit:(UIButton *)sender{
    UIWindow *windows = [UIApplication sharedApplication].keyWindow;
    windows.userInteractionEnabled = NO;
    
    [UIView animateWithDuration:0.25 animations:^{
        self.view.y = self.view.height;
    }completion:^(BOOL finished) {
        self.view.hidden = YES;            //view看不到了，将之隐藏掉，可以减少性能的消耗
//        [self removeCurrentTimer];
//        [self removeLrcTimer];
        windows.userInteractionEnabled = YES;
    }];
}
/**
 *  前一首
 *
 */
- (IBAction)previous:(id)sender {
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    window.userInteractionEnabled = NO;
    [[LCAudioManager defaultManager] stopMusic:self.playingMusic.filename];
    [LCMusicTool setPlayingMusic:[LCMusicTool previousMusic]];
    
    
    [self startPlayingMusic];
    window.userInteractionEnabled = YES;
}

- (IBAction)next:(id)sender {
    UIWindow *window = [UIApplication sharedApplication].keyWindow ;
    window.userInteractionEnabled = NO;
    [[LCAudioManager defaultManager] stopMusic:self.playingMusic.filename];
    [LCMusicTool setPlayingMusic:[LCMusicTool nextMusic]];
    
    
    
    [self startPlayingMusic];
    window.userInteractionEnabled = YES;
}

#pragma mark ----AVAudioPlayerDelegate

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag {
    [self next:nil];
}

#pragma mark --远程控制事件监听
- (BOOL)canBecomeFirstResponder {
    return YES;
}

@end
